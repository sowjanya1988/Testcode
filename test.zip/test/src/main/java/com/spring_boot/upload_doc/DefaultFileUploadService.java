package com.spring_boot.upload_doc;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Date;

import org.springframework.stereotype.Component;

@Component
public class DefaultFileUploadService implements FileUploadService {

  private static final String META_DATA_PROPERTIES = "meta-data.properties";
  private static final String TEMP_DIR = "target";

  public void uploadFile(byte[] bytes, String userName, String date, String fileName) throws IOException {
    String pathToSave = createATempFolder();
    String pathOfFile = String.format("%s/%s", pathToSave, fileName);
    String metaDataFilePath = String.format("%s/%s", pathToSave, META_DATA_PROPERTIES);
    Files.write(Paths.get(pathOfFile), bytes, StandardOpenOption.CREATE);
    Files.write(Paths.get(metaDataFilePath), getFormattedMetaData(userName, date).getBytes(),
        StandardOpenOption.CREATE);
  }

  private String createATempFolder() {
    String pathname = String.format("%s/%s", TEMP_DIR, new Date().getTime());
    File file = new File(pathname);
    file.mkdir();
    return pathname;
  }

  private String getFormattedMetaData(String userName, String date) {
    return String.format("user-name:%s,date:%s", userName, date);
  }

}
