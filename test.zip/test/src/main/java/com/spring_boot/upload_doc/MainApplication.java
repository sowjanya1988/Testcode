package com.spring_boot.upload_doc;

import javax.servlet.MultipartConfigElement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.embedded.MultipartConfigFactory;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan
@EnableAutoConfiguration
public class MainApplication extends SpringBootServletInitializer {

  public static void main(String[] args) {
    SpringApplication.run(MainApplication.class, args);
  }

  @Override
  protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
    return application.sources(MainApplication.class);
  }

  @Bean
  public MultipartConfigElement multipartConfigElement() {
    return new MultipartConfigFactory().createMultipartConfig();
  }

  @Bean
  public FileUploadService fileUploadService() {
    return new DefaultFileUploadService();
  }
}
