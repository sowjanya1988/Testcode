package com.spring_boot.upload_doc;

import java.io.IOException;

public interface FileUploadService {

  void uploadFile(byte[] bytes, String userName, String date, String fileName) throws IOException;

}
